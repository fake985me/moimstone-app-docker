<template>
  <div class="text-center text-gray-500 mt-4">
    Diagram belum tersedia untuk produk ini.
  </div>
</template>

<script setup>
</script>
