<template>
  <div class="guest-layout">
    <slot />
  </div>
</template>
